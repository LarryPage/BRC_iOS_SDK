//
//  BSConfigs.h
//  BrcIot
//
//  Created by tian on 2018/11/11.
//  Copyright © 2018年 tian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BSConfigs : NSObject

+ (NSString * _Nonnull)APIServer;

@end
