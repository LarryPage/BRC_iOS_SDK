//
//  BrcIot.h
//  BrcIot
//
//  Created by tian on 2018/11/11.
//  Copyright © 2018年 tian. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BrcIot.
FOUNDATION_EXPORT double BrcIotVersionNumber;

//! Project version string for BrcIot.
FOUNDATION_EXPORT const unsigned char BrcIotVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BrcIot/PublicHeader.h>

#import "BSConfigs.h"
#import "BSApi.h"
